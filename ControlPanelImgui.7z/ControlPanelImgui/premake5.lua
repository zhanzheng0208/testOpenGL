workspace "ControlPanelImgui"
	location "build"
	architecture "x86"
	startproject "controlPanel"

	configurations
	{
		"Debug",
		"Release"
	}

	flags
	{
		"MultiProcessorCompile"
	}

outputdir = "%{cfg.buildcfg}-%{cfg.system}-%{cfg.architecture}"
imguiDir = "%{wks.location}/../imgui"

include "controlPanel"

group "Dependencies"
	include "imgui"
group ""
