/*----------------------------- FILE PROLOGUE -------------------------------*/
/******************************************************************
 * COPYRIGHT:
 *   2023
 *   SAVIC
 *   All Rights Reserved
 *
 * FILE NAME:
 *   MAP_Mode_Ctrl.c
 *
 * FILE DESCRIPTION:
 *   MAP mode control process. MAP will check the input parameters and calculate
 *   the parameters update flag. The input parameters update flag will drive the
 *   map schedule process, such as calculate the display range and update the needed
 *   resources.
 *   Also, the (mapmode) update flag is used to update the map ring size and position.
 *
 * DEFINED FUNCTION:
 *   MAP_Mode_Ctrl_Update
 *   MAP_Get_Map_Mode_Update_Flag
 *   MAP_Get_Ring_Range_Update_Flag
 *   MAP_Get_Yaw_Update_Flag
 *   MAP_Get_Position_Update_Flag
 *
 * DESIGN NOTES:
 *   None.
 *
 * Create Date:
 *   2023-02-23
 *
******************************************************************/

/*----------------------------- FILE INCLUSION ------------------------------*/
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "MAP_Grid.h"
#include "MAP_Mode_Ctrl.h"
#include "MAP_Cam.h"
/*---------------------------- MACRO DEFINITIONS ----------------------------*/

/*---------------------------- TYPE DECLARATIONS ----------------------------*/

/*-------------------------- VARIABLE DEFINITIONS ---------------------------*/
MAP_LOCAL sMapInputs latest_input_params[WINDOW_NUM] = { 0 };
MAP_LOCAL bool         map_mode_update_flag[WINDOW_NUM] = { 0 };
MAP_LOCAL bool         ring_range_update_flag[WINDOW_NUM] = { 0 };
MAP_LOCAL bool         yaw_update_flag[WINDOW_NUM] = { 0 };
MAP_LOCAL bool         pos_update_flag[WINDOW_NUM] = { 0 };

/*-------------------------- FUNCTION DECLARATIONS --------------------------*/
/******************************************************************************
 * @brief
 *****************************************************************************/

 /*-------------------------- FUNCTION DEFINITIONS ---------------------------*/
static Geo_Wgs84_t pixelToWgs84(Int32 p_channel, Int32 p_xPixel, Int32 p_yPixel)
{
    //��������תNDC����
    sMapWindow* window = Param_Window_Get(p_channel);
    Int32* viewport = Cam_Mgr_Get_Viewport(p_channel);
    Float64 xNDC = (Float64)(p_xPixel - viewport[2] / 2) / viewport[2] * 2;
    Float64 yNDC = (Float64)(p_yPixel - viewport[3] / 2) / viewport[3] * 2;
    Float64 zNDC = -1; //���������ǽ�ƽ�����������

    //NDC����ת�������
    const Mat4f* projMat = Cam_Mgr_Get_Projection(p_channel);
    Float64      xView = (xNDC - projMat->col[3].x) / projMat->col[0].x;
    Float64      yView = (yNDC - projMat->col[3].y) / projMat->col[1].y;
    Float64      zView = (zNDC - projMat->col[3].z) / projMat->col[2].z;

    //�������ת��������(ECEF)
    const Mat4f* viewMatR = Cam_Mgr_Get_Modelview(p_channel);
    Float64 xViewR = xView * viewMatR->col[0].x + yView * viewMatR->col[0].y + zView * viewMatR->col[0].z;
    Float64 yViewR = xView * viewMatR->col[1].x + yView * viewMatR->col[1].y + zView * viewMatR->col[1].z;
    Float64 zViewR = xView * viewMatR->col[2].x + yView * viewMatR->col[2].y + zView * viewMatR->col[2].z;

    const Vec3d* camPos = Cam_Mgr_Get_Position(p_channel);
    Vec3d newWord;
    newWord.x = xViewR + camPos->x;
    newWord.y = yViewR + camPos->y;
    newWord.z = zViewR + camPos->z;

    //�����ƽ��ƽ�淽�̣�ʹ�õ���ʽֱ��(����)����
    const Mat4f* projViewR = Cam_Mgr_Get_ProjectionViewR(p_channel);
    Mat4f ProjView;
    Mat4f viewMatT = {1, 0, 0, 0,
                      0, 1, 0, 0,
                      0, 0, 1, 0,
                      -camPos->x, -camPos->y, -camPos->z, 1};
    Mat4f_Mul_Mat4f(projViewR, &viewMatT, &ProjView);
    Float64 nearA = ProjView.col[0].w + ProjView.col[0].z;
    Float64 nearB = ProjView.col[1].w + ProjView.col[1].z;
    Float64 nearC = ProjView.col[2].w + ProjView.col[2].z;
    Float64 nearD = ProjView.col[3].w + ProjView.col[3].z;


    //����ֱ������򽻵�
    Float64 a = (nearA * nearA + nearB * nearB) / GEO_GREAT_HALF_AXIS_SQUARED + nearC * nearC / GEO_SMALL_HALF_AXIS_SQUARED;
    Float64 b = (2 * nearA * newWord.x + 2 * nearB * newWord.y) / GEO_GREAT_HALF_AXIS_SQUARED + 2 * nearC * newWord.z / GEO_SMALL_HALF_AXIS_SQUARED;
    Float64 c = (newWord.x * newWord.x + newWord.y * newWord.y) / GEO_GREAT_HALF_AXIS_SQUARED + (newWord.z * newWord.z) / GEO_SMALL_HALF_AXIS_SQUARED - 1;
    Float64 t1 = (-b + sqrt(b * b - 4 * a * c)) / (2 * a);
    Float64 t2 = (-b - sqrt(b * b - 4 * a * c)) / (2 * a);

    Vec3d interPos;
    Vec3d interPos1;
    interPos1.x = nearA * t1 + newWord.x;
    interPos1.y = nearB * t1 + newWord.y;
    interPos1.z = nearC * t1 + newWord.z;

    Vec3d interPos2;
    interPos2.x = nearA * t2 + newWord.x;
    interPos2.y = nearB * t2 + newWord.y;
    interPos2.z = nearC * t2 + newWord.z;

    //�Ƚ���������ͽ�ƽ��ľ��룬ʹ�ý��Ľ���
    Float64 l = sqrt(nearA * nearA + nearB * nearB + nearC * nearC);
    Float64 dis1 = (nearA * interPos1.x + nearB * interPos1.y + nearC * interPos1.z + nearD) / l;
    Float64 dis2 = (nearA * interPos2.x + nearB * interPos2.y + nearC * interPos2.z + nearD) / l;
    if (dis1 < dis2) {
        interPos = interPos1;
    }
    else {
        interPos = interPos2;
    }
    printf("%f %f\n", dis1, dis2);

    //ECEF����תWG484����
    Geo_Wgs84_t interPosWgs84 = Geo_Ecef_To_Wgs84(&interPos);
    return interPosWgs84;
}

static void setRoamPostionKey(Int32 channel, sMapInputs* inputs, Int32 keyDir)
{
    sMapWindow* window = Param_Window_Get(channel);
    Int32 xPixel, yPixel;
    Int32 offset;
    switch (keyDir) {
    case 0: //��
        offset = (window->h - window->rot_y) / 4;
        xPixel = window->rot_x;
        yPixel = window->rot_y + offset;
        break;
    case 1: //��
        offset = window->rot_y / 4;
        xPixel = window->rot_x;
        yPixel = window->rot_y - offset;
        break;
    case 2: //��
        offset = window->rot_x / 4;
        xPixel = window->rot_x - offset;
        yPixel = window->rot_y;
        break;
    case 3: //��
        offset = (window->w - window->rot_y) / 4;
        xPixel = window->rot_x + offset;
        yPixel = window->rot_y;
        break;
    default:
        xPixel = window->rot_x;
        yPixel = window->rot_y;
        break;
    }

    Geo_Wgs84_t roamPos = pixelToWgs84(channel, xPixel, yPixel);
    //��������Ӿ����ƽ����������꣬�߶���Ҫ�޸�Ϊ��ǰ�ɻ��߶�
    roamPos.alt = inputs->planePos.alt;

    inputs->pos = roamPos;
}

static void setRoamPostionMouse(Int32 channel, sMapInputs* inputs)
{
    Geo_Wgs84_t roamPos = pixelToWgs84(channel, inputs->xPixel, inputs->yPixel);
    //��������Ӿ����ƽ����������꣬�߶���Ҫ�޸�Ϊ��ǰ�ɻ��߶�
    roamPos.alt = inputs->planePos.alt;

    inputs->pos = roamPos;
}

/******************************************************************
 * FUNCTION NAME:
 *   MAP_Mode_Ctrl_Update
 *
 * DESCRIPTION:
 *   MAP control parameters update process
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     latest_input_params
 *     map_mode_update_flag
 *     ring_range_update_flag
 *     yaw_update_flag
 *     pos_update_flag
 *
 *   INPUT:
 *     channel: the output head index (0 or 1 for dual output)
 *     inputs: input parameters for map engine
 *
 *   OUTPUT:
 *     None
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   None
 *
 * NOTES:
 *
 ******************************************************************/
void MAP_Mode_Ctrl_Update(char channel, sMapInputs* inputs)
{
    if (inputs->ctrl.mapMode == 0) {
        inputs->pos = inputs->planePos;
    }
    else {
        static Int32 lastUpPress[2] = { 0, 0 };
        static Int32 lastDownPress[2] = { 0, 0 };
        static Int32 lastLeftPress[2] = { 0, 0 };
        static Int32 lastRightPress[2] = { 0, 0 };
        if (lastUpPress[channel] == 1 && inputs->upPress == 0) {
            setRoamPostionKey(channel, inputs, 0);
        }
        else if (lastDownPress[channel] == 1 && inputs->upPress == 0) {
            setRoamPostionKey(channel, inputs, 1);
        }
        else if (lastLeftPress[channel] == 1 && inputs->upPress == 0) {
            setRoamPostionKey(channel, inputs, 2);
        }
        else if (lastRightPress[channel] == 1 && inputs->upPress == 0) {
            setRoamPostionKey(channel, inputs, 3);
        }
        lastUpPress[channel] = inputs->upPress;
        lastDownPress[channel] = inputs->downPress;
        lastLeftPress[channel] = inputs->leftPress;
        lastRightPress[channel] = inputs->rightPress;

        static Int32 lastMouseClick[2] = {0, 0};
        if (lastMouseClick[channel] == 1 && inputs->mouseClick == 0) {
            setRoamPostionMouse(channel, inputs);
        }
        lastMouseClick[channel] = inputs->mouseClick;
    }

    // 1. check map mode update
    if (inputs->ctrl.mapMode != latest_input_params[channel].ctrl.mapMode) {
        if (fabs(inputs->att.heading) > HEADING_CHANGE_LIMIT) {
            map_mode_update_flag[channel] = true;
        }
        printf("\nMap Control[c:%d]: map mode(%d -> %d)\n",
            channel,
            latest_input_params[channel].ctrl.mapMode,
            inputs->ctrl.mapMode);
        latest_input_params[channel].ctrl.mapMode = inputs->ctrl.mapMode;
    }

    // 2. check ring range update
    if (fabs(inputs->ctrl.range - latest_input_params[channel].ctrl.range) >
        RING_RANGE_CHANGE_LIMIT) {
        ring_range_update_flag[channel] = true;
        printf("\nMap Control[c:%d]: map range(%f -> %f)\n",
            channel,
            latest_input_params[channel].ctrl.range,
            inputs->ctrl.range);
        latest_input_params[channel].ctrl.range = inputs->ctrl.range;
    }

    // 3. check yaw/heading update
    if (fabs(inputs->att.heading - latest_input_params[channel].att.heading) >
        HEADING_CHANGE_LIMIT) {
        if (inputs->ctrl.mapMode == 0) {
            yaw_update_flag[channel] = true;
        }
        printf("\nMap Control[c:%d]: map heading(%f -> %f)\n",
            channel,
            latest_input_params[channel].att.heading,
            inputs->att.heading);
        latest_input_params[channel].att.heading = inputs->att.heading;
    }

    // 4. check position update
    if ((fabs(inputs->pos.lon - latest_input_params[channel].pos.lon) > POSITION_CHANGE_LIMIT) ||
        (fabs(inputs->pos.lat - latest_input_params[channel].pos.lat) > POSITION_CHANGE_LIMIT)) {
        pos_update_flag[channel] = true;
#if 0
        printf("\nMap Control[c:%d]: map pos(%f,%f) -> (%f,%f)\n",
            channel,
            latest_input_params[channel].pos.lon,
            latest_input_params[channel].pos.lat,
            inputs->pos.lon,
            inputs->pos.lat);
#endif
        latest_input_params[channel].pos = inputs->pos;
    }

    // 5. update the range ring parameters
    if (map_mode_update_flag[channel] == true) {
        MAP_Set_Widnow_Ring(channel,
            Config_Get_Screen_Rot_X(inputs->ctrl.mapMode),
            Config_Get_Screen_Rot_Y(inputs->ctrl.mapMode),
            Config_Get_MAP_Range_R(inputs->ctrl.mapMode));
    }

    // 6. set the grid update flag
    MAP_Grid_Set_Update(channel);

    return;
}

/******************************************************************
 * FUNCTION NAME:
 *   MAP_Get_Map_Mode_Update_Flag
 *
 * DESCRIPTION:
 *   get map-mode control parameter update flag
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     map_mode_update_flag: the update flag for map-mode parameter
 *
 *   INPUT:
 *     channel: the output head index (0 or 1 for dual output)
 *
 *   OUTPUT:
 *     None
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   true: map-mode control parameter is updated
 *   false: map-mode comtrol parameter is not updated
 *
 * NOTES:
 *
 ******************************************************************/
bool MAP_Get_Map_Mode_Update_Flag(char channel)
{
#if MAP_DEBUG
    if (map_mode_update_flag[channel] == true) {
        printf("map mode Update.\n");
    }
#endif
    bool ret = map_mode_update_flag[channel];
    map_mode_update_flag[channel] = false;
    return ret;
}

/******************************************************************
 * FUNCTION NAME:
 *   MAP_Get_Ring_Range_Update_Flag
 *
 * DESCRIPTION:
 *   get map ring range parameter update flag
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     ring_range_update_flag: the update flag for range ring parameter
 *
 *   INPUT:
 *     channel: the output head index (0 or 1 for dual output)
 *
 *   OUTPUT:
 *     None
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   true: map ring range is updated
 *   false: map ring range is not updated
 *
 * NOTES:
 *
 ******************************************************************/
bool MAP_Get_Ring_Range_Update_Flag(char channel)
{
#if MAP_DEBUG
    if (ring_range_update_flag[channel] == true) {
        printf("Range Update.\n");
    }
#endif
    bool ret = ring_range_update_flag[channel];
    ring_range_update_flag[channel] = false;
    return ret;
}

/******************************************************************
 * FUNCTION NAME:
 *   MAP_Get_Yaw_Update_Flag
 *
 * DESCRIPTION:
 *   get map heading/yaw parameters update flag
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     yaw_update_flag: the update flag for heading parameter
 *
 *   INPUT:
 *     channel: the output head index (0 or 1 for dual output)
 *
 *   OUTPUT:
 *     None
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   true: map heading/yaw is updated
 *   false: map heading/yaw is not updated
 *
 * NOTES:
 *
 ******************************************************************/
bool MAP_Get_Yaw_Update_Flag(char channel)
{
#if MAP_DEBUG
    if (yaw_update_flag[channel] == true) {
        printf("yaw Update.\n");
    }
#endif
    bool ret = yaw_update_flag[channel];
    yaw_update_flag[channel] = false;
    return ret;
}

/******************************************************************
 * FUNCTION NAME:
 *   MAP_Get_Position_Update_Flag
 *
 * DESCRIPTION:
 *   get map position parameters update flag
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     pos_update_flag: the update flag for position parameter
 *
 *   INPUT:
 *     channel: the output head index (0 or 1 for dual output)
 *
 *   OUTPUT:
 *     None
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   true: map position is changed
 *   false: map position is not changed
 *
 * NOTES:
 *
 ******************************************************************/
bool MAP_Get_Position_Update_Flag(char channel)
{
#if MAP_DEBUG
    MAP_LOCAL Uint32 count = 0;
    if (pos_update_flag[channel] == true) {
        printf("pos Update.[%d]\n", count++);
    }
#endif
    bool ret = pos_update_flag[channel];
    pos_update_flag[channel] = false;
    return ret;
}
