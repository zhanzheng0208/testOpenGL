#ifndef CONTROL_PANEL
#define CONTROL_PANEL

#include "MAP_Param_In.h"


typedef struct ControlPanel {
	void* sharedMemBuf;
} ControlPanel;


ControlPanel* ControlPanel_instance();
void * ControlPanel_init(ControlPanel* this);

#endif
