#include <windows.h>
#include "controlPanel.h"
#include "stdbool.h"


static void* initSharedMem();


ControlPanel *ControlPanel_instance()
{
	static ControlPanel s_controlPanel;
	return &s_controlPanel;
}

void* ControlPanel_init(ControlPanel *this)
{
	while (1) {
		this->sharedMemBuf = initSharedMem();
		if (this->sharedMemBuf) {
			break;
		}
		Sleep(1000);
	}

	return this->sharedMemBuf;
}

static void* initSharedMem()
{
	HANDLE oshandle = NULL;
	void* buf;

	while (!oshandle) {
		oshandle = OpenFileMapping(FILE_MAP_ALL_ACCESS, FALSE, "DmapSharedMem");
		if (!oshandle) {
			printf("Could not open file mapping.\n");
			return NULL;
		}
	}

	buf = MapViewOfFile(
		oshandle,   /* handle to map object  */
		FILE_MAP_ALL_ACCESS,        /* read/write permission */
		0,
		0,
		2048);
	if (buf == NULL) {
		printf(TEXT("Could not map view of file (%d).\n"), GetLastError());
		CloseHandle(oshandle);
		return NULL;
	}

	return buf;
}
