#pragma once
#include <list>
#include <iostream>

class Event
{
public:
	enum EventType {
		MOUSE_CLICK,
	};

	EventType getEventType()
	{
		return _eventType;
	}
	virtual ~Event()
	{
		std::cout << "~Event()" << std::endl;
	}

protected:
	EventType _eventType;
};

class MouseClick : public Event
{
public:
	MouseClick(int32_t p_posX, int32_t p_poxY)
	{
		_posX = p_posX;
		_posY = p_poxY;
		_eventType = Event::MOUSE_CLICK;
	}

	~MouseClick()
	{
		std::cout << "~MouseClick" << std::endl;
	}
	
	int32_t getPosX()
	{
		return _posX;
	}
	int32_t getPosY()
	{
		return _posY;
	}

private:
	int32_t _posX = 0;
	int32_t _posY = 0;
};

class EventQueue
{
public:
	typedef std::list<Event*> EventList;

	EventQueue()
	{

	}
	void pushBack(Event *p_event)
	{
		_eventQueue.push_back(p_event);
	}

	EventList& getEventList()
	{
		return _eventQueue;
	}

private:
	EventList _eventQueue;
};
