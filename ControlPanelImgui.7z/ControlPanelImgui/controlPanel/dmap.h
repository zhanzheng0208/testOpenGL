#pragma once
#include <stdint.h>
#include "sharedMem.h"
#include "MAP_Geo.h"


struct DmapOut {
    float          longitude;
    int32_t        longitudeStatus;
    float          latitude;
    int32_t        latitudeStatus;
    float          altitude;
    int32_t        altitudeStatus;
    float          pitch;
    int32_t        pitchStatus;
    float          roll;
    int32_t        rollStatus;
    float          heading;
    int32_t        headingStatus;
    float          ring_range;    // m
    int32_t        map_mode;
};

class DMap {
public:
	DMap();
	~DMap();

    void run(int32_t channel);

private:
    void getDisAndAngleByGeo(Geo_Wgs84_t* s, Geo_Wgs84_t* e, double* dis, double* alpha);

private:
	SharedMem _sharedMem;
    DmapOut *_dmapOut = nullptr;
};