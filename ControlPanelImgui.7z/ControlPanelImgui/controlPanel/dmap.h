#pragma once
#include <stdint.h>
#include "sharedMem.h"
#include "MAP_Geo.h"
#include "hook.h"
#include "eventQueue.h"

#define KEEP_PRAME 3

class DMap;
class DmapGui
{
public:
    friend DMap;

    DmapGui(DMap* p_dmap);
    ~DmapGui();

    void setIsRoam(bool p_isRoam1, bool p_isRoam2)
    {
        _isRoams[0] = p_isRoam1;
        _isRoams[1] = p_isRoam2;
    }

    void frame();

private:
    DMap* _dmap;
    bool _isRoams[2] = { false, false };
};

class DMap {
public:
    struct DmapOut {
        float   longitude;
        int32_t longitudeStatus;
        float   latitude;
        int32_t latitudeStatus;
        float   altitude;
        int32_t altitudeStatus;
        float   pitch;
        int32_t pitchStatus;
        float   roll;
        int32_t rollStatus;
        float   heading;
        int32_t headingStatus;
        float   ring_range; // m
        int32_t map_mode;

        //���ΰ���״̬
        int32_t upPress;
        int32_t downPress;
        int32_t leftPress;
        int32_t rightPress;

        int32_t mouseClick;
        int32_t xPixel;
        int32_t yPixel;
    };

	DMap();
	~DMap();

    //void run(int32_t channel);

    void frame();
    void autoRunTest(int32_t p_channel);

    void setMapMode(int32_t p_channel, bool p_isRoam);
    void setRoamKeyUp(int32_t p_channel, bool p_status);
    void setRoamKeyDown(int32_t p_channel, bool p_status);
    void setRoamKeyLeft(int32_t p_channel, bool p_status);
    void setRoamKeyRight(int32_t p_channel, bool p_status);
    void setRoamPixelPos(int32_t p_xPos, int32_t p_yPos);
    void setRoamPixelPosThread(int32_t channel, int32_t p_xPos, int32_t p_yPos);

private:
    void getDisAndAngleByGeo(Geo_Wgs84_t* s, Geo_Wgs84_t* e, double* dis, double* alpha);

private:
    DmapGui* _dmapGui;

    SharedMem *_sharedMem;
    DmapOut *_dmapOut = nullptr;
    EventQueue* _eventQueue;
};