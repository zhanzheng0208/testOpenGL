#pragma once

#include <windows.h>
#include <winuser.h>
#include "eventQueue.h"

class DMap;
class Hook
{
public:
	static Hook *instance();

	void setEventQueue(EventQueue *eventQueue);
	void installHook();
	void unInstallHook();

	static LRESULT CALLBACK keyProc(int nCode, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK mouseProc(int nCode, WPARAM wParam, LPARAM lParam);

private:
	void _handleMouseEvent(WPARAM wParam, LPARAM lParam);

	static HHOOK s_keyHook;
	static HHOOK s_mouseHook;

	EventQueue *_eventQueue;
};