/******************************************************************
 * COPYRIGHT: 
 *   2023
 *   SAVIC
 *   All Rights Reserved
 *
 * FILE NAME:
 *   MAP_Geo.h
 *
 * DESCRIPTION:
 *   This file provides geographic calculating
 *
 * Create Date:
 *   2023-02-23
 *
******************************************************************/

#ifndef _MAP_GEO_H_
#define _MAP_GEO_H_

#ifdef __cplusplus
extern "C" {
#endif

/*----------------------------- FILE INCLUSION ------------------------------*/
#include "MAP_Math.h"


/*---------------------------- MACRO DEFINITIONS ----------------------------*/
#define GEO_GREAT_HALF_AXIS         ((double)6378137.0)
#define GEO_SMALL_HALF_AXIS         ((double)6356752.314245179)
#define GEO_GREAT_HALF_AXIS_SQUARED ((double)40680631590769.0)
#define GEO_SMALL_HALF_AXIS_SQUARED ((double)40408299984661.445)
#define GEO_MEAN_RADIUS             ((double)6376500.0)
#define GEO_MEAN_PERIMETER          ((double)40064731.11123)

#define GEO_K_FIRST_ECCENTRICITY_SQUARED  ((double)6.69437999014133 * 0.001)
#define GEO_K_SECOND_ECCENTRICITY_SQUARED ((double)6.73949674228 * 0.001)
#define GEO_KFLATTENING                   ((double)1.0 / 298.257223563)

/*---------------------------- TYPE DECLARATIONS ----------------------------*/
/******************************************************************/
/*   the wgs84 coordinate of a point                        */
/******************************************************************/
typedef struct Geo_Wgs84_t {
    double lon; /* lontitude */
    double lat; /* latitude */
    double alt; /* altitude */
} Geo_Wgs84_t;  /* wgs84 position */

/******************************************************************/
/*   the altitude of aircraft                        */
/******************************************************************/
typedef struct Geo_Attitude_t {
    double pitch;   /* pitch in degree */
    double heading; /* heading in degree */
    double roll;    /* roll in degree */
} Geo_Attitude_t;

/*-------------------------- VARIABLE DECLARATIONS --------------------------*/

/*-------------------------- FUNCTION DECLARATIONS --------------------------*/
/*****************************************************************************/
/* Normalize longitude and latitude                                          */
/*****************************************************************************/
void Geo_Normalize_Lonlat(Geo_Wgs84_t *in_out);

/*****************************************************************************/
/* Convert wgs84 coordinates to ECEF coordinates                             */
/*****************************************************************************/
Vec3d Geo_Wgs84_To_Ecef(const Geo_Wgs84_t *pos);

/*****************************************************************************/
/* Convert ECEF coordinates to wgs84 coordinates                             */
/*****************************************************************************/
Geo_Wgs84_t Geo_Ecef_To_Wgs84(const Vec3d *v);

/*****************************************************************************/
/* Calculate the degree of two wgs84 points.                                 */
/*****************************************************************************/
double Geo_Deg_With_North(double lon0, double lat0, double lon1, double lat1);

#ifdef __cplusplus
}
#endif

#endif /* _MAP_GEO_H_ */
