#pragma once

#include "windows.h"


class SharedMem {
public:
	SharedMem();
	~SharedMem();

	void* init();

private:
	
	void* _data;
	HANDLE _hMapFile;
};