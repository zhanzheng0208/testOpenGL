/******************************************************************
 * COPYRIGHT: 
 *   2023
 *   SAVIC
 *   All Rights Reserved
 *
 * FILE NAME:
 *   MAP_Geo.c
 *
 * FILE DESCRIPTION:
 *   This file provides geographic calculating
 *
 * DEFINED FUNCTION:
 *   Geo_Normalize_Lonlat
 *   Geo_Wgs84_To_Ecef
 *   Geo_Ecef_To_Wgs84
 *   Geo_Deg_With_North
 *   Geo_transEcef2Sphere
 *   Geo_transGeo2Sphere
 *   Geo_transSphere2Geo
 *
 * DESIGN NOTES:
 *   None.
 *
 * Create Date:
 *   2023-02-23
 *
******************************************************************/

/*----------------------------- FILE INCLUSION ------------------------------*/
#include "MAP_Geo.h"

#include <stdint.h>
#include <math.h> /* for fabs */
#if MAP_DEBUG
#    include <time.h>
#endif

/*---------------------------- MACRO DEFINITIONS ----------------------------*/
#define CORRECTIVE_FACTOR(lat) \
    ((GEO_SMALL_HALF_AXIS + (GEO_GREAT_HALF_AXIS - GEO_SMALL_HALF_AXIS) * (1.0 - lat / 90.0)))
#define LAT_TO_METER_FACTOR(lat) (M_PI * CORRECTIVE_FACTOR(lat) / 180.0)

/*---------------------------- TYPE DECLARATIONS ----------------------------*/

/*-------------------------- VARIABLE DEFINITIONS ---------------------------*/

/*-------------------------- FUNCTION DECLARATIONS --------------------------*/

/*-------------------------- FUNCTION DEFINITIONS ---------------------------*/
/******************************************************************
 * FUNCTION NAME:
 *   Geo_Normalize_Lonlat
 *
 * DESCRIPTION:
 *   Normalize longitude and latitude
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     None
 *
 *   INPUT:
 *     in_out:
 *
 *   OUTPUT:
 *     None
 *
 *   INPUT/OUTPUT:
 *     in_out: normalize input and output
 *
 * RETURN CODE:
 *   None
 *
 * NOTES:
 *
 ******************************************************************/
void Geo_Normalize_Lonlat(Geo_Wgs84_t *in_out)
{
    /* if longitude is out of the normalized range, correct the value */
    in_out->lon = fmod(in_out->lon + 540.0, 360.0) - 180.0;

    /* if latitude is out of the normalized range, correct the value */
    if (in_out->lat < -90.0) {
        in_out->lat = -90.0 + (-in_out->lat - 90.0);
        in_out->lon = (180.0 - fabs(in_out->lon)) * (in_out->lon > 0.0 ? -1.0 : 1.0);
    }
    else if (in_out->lat > 90.0) {
        in_out->lat = 90.0 - (in_out->lat - 90.0);
        in_out->lon = (180.0 - fabs(in_out->lon)) * (in_out->lon > 0.0 ? -1.0 : 1.0);
    }
}

/******************************************************************
 * FUNCTION NAME:
 *   Geo_Wgs84_To_Ecef
 *
 * DESCRIPTION:
 *   Convert wgs84 coordinates to ECEF coordinates
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     None
 *
 *   INPUT:
 *     pos: pointer to current position
 *
 *   OUTPUT:
 *     return ECEF coordinates
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   None
 *
 * NOTES:
 *
 ******************************************************************/
Vec3d Geo_Wgs84_To_Ecef(const Geo_Wgs84_t *pos)
{
    Vec3d ret = {0.0, 0.0, 0.0};

    double lon = pos->lon;
    double lat = pos->lat;
    double alt = pos->alt;
    lon *= M_DEG2RAD;
    lat *= M_DEG2RAD;
    double sin_lat = sin(lat);
    double cos_lat = cos(lat);
    double xi      = sqrt(1 - GEO_K_FIRST_ECCENTRICITY_SQUARED * sin_lat * sin_lat);
    double help    = GEO_GREAT_HALF_AXIS / xi;
    ret.x          = (double)((help + alt) * cos_lat * cos(lon));
    ret.y          = (double)((help + alt) * cos_lat * sin(lon));
    ret.z          = (double)((help * (1 - GEO_K_FIRST_ECCENTRICITY_SQUARED) + alt) * sin_lat);

    return ret;
}

/******************************************************************
 * FUNCTION NAME:
 *   Geo_Ecef_To_Wgs84
 *
 * DESCRIPTION:
 *   Convert ECEF coordinates to wgs84 coordinates
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     None
 *
 *   INPUT:
 *     v: ecef x,y,z
 *
 *   OUTPUT:
 *     return WGS 84 coordinates
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   None
 *
 * NOTES:
 *
 ******************************************************************/
Geo_Wgs84_t Geo_Ecef_To_Wgs84(const Vec3d *v)
{
    Geo_Wgs84_t  ret = {0.0, 0.0, 0.0};
    uint32_t i   = 0;
    double       a2  = GEO_GREAT_HALF_AXIS_SQUARED;
    double       b2  = GEO_SMALL_HALF_AXIS_SQUARED;
    double       e2  = GEO_K_FIRST_ECCENTRICITY_SQUARED;
    double       x   = v->x;
    double       y   = v->y;
    double       z   = v->z;
    double       p   = sqrt(x * x + y * y);

    double theta = atan2(z, p * (1.0 - e2));
    double cs    = cos(theta);
    double sn    = sin(theta);
    double N     = a2 / sqrt(a2 * cs * cs + b2 * sn * sn);
    double h     = p / cs - N;

    for (i = 0; i < 2; i++) {
        theta = atan2(z, p * (1.0 - e2 * N / (N + h)));
        cs    = cos(theta);
        sn    = sin(theta);
        N     = a2 / sqrt(a2 * cs * cs + b2 * sn * sn);
        h     = p / cs - N;
    }

    ret.lon = atan2(y, x) * M_RAD2DEG;
    ret.lat = theta * M_RAD2DEG;
    ret.alt = h;

    return ret;
}

/******************************************************************
 * FUNCTION NAME:
 *   Geo_Deg_With_North
 *
 * DESCRIPTION:
 *   calculate the degree of two wgs84 points.
 *
 * INTERFACE:
 *   GLOBAL DATA:
 *     None
 *
 *   INPUT:
 *     lon0: the longtidute of point1
 *     lat0: the latitude of point1
 *     lon1: the longtitude of point2
 *     lat1: the latitude of point2
 *
 *   OUTPUT:
 *     return the degree of two wgs84 points
 *
 *   INPUT/OUTPUT:
 *     None
 *
 * RETURN CODE:
 *   None
 *
 * NOTES:
 *
 ******************************************************************/
double Geo_Deg_With_North(double lon0, double lat0, double lon1, double lat1)
{
    double dlon = lon1 - lon0;
    if (dlon > 180.0) {
        dlon -= 360;
    }
    else if (dlon < -180.0) {
        dlon += 360;
    }

    double dlat = lat1 - lat0;
    double degree;

    if (fabs(dlat) < 0.000000001) {
        if (dlon < 0) {
            degree = 270.0;
        }
        else {
            degree = 90.0;
        }
    }
    else {
        degree = atan(dlon * cos(lat1 * M_DEG2RAD) / dlat) * M_RAD2DEG;
        if (dlat < 0.0) {
            if (dlon > 0.0) {
                degree += 180.0;
            }
            else {
                degree -= 180.0;
            }
        }
    }

    return degree;
}
