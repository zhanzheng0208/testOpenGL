#include <iostream>
#include "dMap.h"
#include "sharedMem.h"
#include "MAP_Geo.h"
#include "imgui.h"
#include <thread>


DmapGui::DmapGui(DMap* p_dmap)
{
    _dmap = p_dmap;
}

DmapGui::~DmapGui()
{
}

void DmapGui::frame()
{
    static char* s_winName[2] = {
        "DMAP1", "DMAP2"
    };
    for (int channel = 0; channel < 2; channel++) {
        if (ImGui::Begin(s_winName[channel])) {
            if (ImGui::Checkbox("Roam", &_isRoams[channel])) {
                _dmap->setMapMode(channel, _isRoams[channel]);
            }

            bool upPress = ImGui::Button("Up"); ImGui::SameLine();
            bool downPress = ImGui::Button("Down"); ImGui::SameLine();
            bool leftPress = ImGui::Button("Left"); ImGui::SameLine();
            bool rightPress = ImGui::Button("Right"); ImGui::SameLine();
            _dmap->setRoamKeyUp(channel, upPress);
            _dmap->setRoamKeyDown(channel, downPress);
            _dmap->setRoamKeyLeft(channel, leftPress);
            _dmap->setRoamKeyRight(channel, rightPress);

            ImGui::End();
        }
    }
}

DMap::DMap()
{
    _sharedMem = new SharedMem;
	_dmapOut = (DmapOut*)_sharedMem->init();

    for (int32_t i = 0; i < 2; i++) {
        _dmapOut[i].longitude = 121.793333333948;
        _dmapOut[i].latitude = 31.1449999998139;
        _dmapOut[i].altitude = 2000.0;
        _dmapOut[i].pitch = -90.0;
        _dmapOut[i].heading = 0.0;
        _dmapOut[i].roll = 0.0;
        _dmapOut[i].ring_range = 100.0 * 1000.0;
        _dmapOut[i].map_mode = 0;
        _dmapOut[i].upPress = 0;
        _dmapOut[i].downPress = 0;
        _dmapOut[i].leftPress = 0;
        _dmapOut[i].rightPress = 0;
        _dmapOut[i].mouseClick = 0;
        _dmapOut[i].xPixel = 0;
        _dmapOut[i].yPixel = 0;
    }

    _dmapGui = new DmapGui(this);
    _dmapGui->setIsRoam(false, false);

    _eventQueue = new EventQueue;
    Hook *hook = Hook::instance();
    hook->installHook();
    hook->setEventQueue(_eventQueue);
}

DMap::~DMap()
{
    if (_dmapGui) {
        delete _dmapGui;
    }
    if (_sharedMem) {
        delete _sharedMem;
    }
}

void DMap::frame()
{
    _dmapGui->frame();
    autoRunTest(0);
    autoRunTest(1);

    //�����¼�����
    EventQueue::EventList &eventList = _eventQueue->getEventList();
    EventQueue::EventList::iterator itor;
    for (itor = eventList.begin(); itor != eventList.end();) {
        Event *event = (*itor);
        if (event->getEventType() == Event::MOUSE_CLICK) {
            MouseClick* mouseClick = (MouseClick*)event;
            setRoamPixelPos(mouseClick->getPosX(), mouseClick->getPosY());
        }
        delete event;
        itor = eventList.erase(itor);
    }
}

void DMap::autoRunTest(int32_t p_channel)
{
    Geo_Wgs84_t    cur_loc = { 0.0 };
    static double angle[2] = { 0.0 };
    int32_t          line_index = 0;
    static uint32_t  framecount[2] = { 0 };
    static int32_t   init_flag = 0;

    static int32_t init[2] = { 0 };
    static int32_t alt = 1000;
    static int32_t alt_dir[2] = { 1 };
    static double     step = 50.0;

    Geo_Wgs84_t  lujiazui = { 121.49971691534425, 31.239658843127756, 3.0 };
    Geo_Wgs84_t  pudong = { 121.793333333948, 31.1449999998139, 3.0 };
    Geo_Wgs84_t  hangzhou = { 120.793333333948, 30.1449999998139, 3.0 };
    Geo_Wgs84_t  jinwan = { 113.39579, 22.01721, 3.0 };
    Geo_Wgs84_t  jiujiang = { 116.1, 29.5, 3.0 };
    Geo_Wgs84_t  temDes = { 113.39579, 42.01721, 3.0 };
    Geo_Wgs84_t  yueyang = { 113.1, 29.5, 3.0 };
    Geo_Wgs84_t  testP = { 112.6, 31.5, 3.0 };

    Geo_Wgs84_t* pDest = &pudong;
    Geo_Wgs84_t* pSrc = &jinwan;
    if (p_channel == 1) {
        pDest = &pudong;
        pSrc = &jinwan;
    }
    else {
        pDest = &jiujiang;
        pSrc = &hangzhou;
    }
    static double dis[2] = { 0.0 };
    static double heading[2] = { 0.0 };
    if (init[p_channel] == 0) {
        init[p_channel] = 1;
        getDisAndAngleByGeo(pSrc, pDest, &dis[p_channel], &heading[p_channel]);
    }
    double step_away = step * framecount[p_channel];
    double ratio = step_away / dis[p_channel];
    if (step_away > dis[p_channel])
        framecount[p_channel] = 0;
    Geo_Wgs84_t pos;
    pos.lon = pSrc->lon + ratio * (pDest->lon - pSrc->lon);
    pos.lat = pSrc->lat + ratio * (pDest->lat - pSrc->lat);
    alt += alt_dir[p_channel] * 20.0;
    if (alt > 3000) {
        alt_dir[p_channel] = -1;
    }
    else if (alt < 900) {
        alt_dir[p_channel] = 1;
    }
    pos.alt = alt;


    framecount[p_channel]++;

    Geo_Normalize_Lonlat(&pos);

    _dmapOut[p_channel].longitude = pos.lon;
    _dmapOut[p_channel].latitude = pos.lat;
    _dmapOut[p_channel].altitude = pos.alt;
    _dmapOut[p_channel].heading = heading[p_channel];
}

void DMap::setMapMode(int32_t p_channel, bool p_isRoam)
{
    if (p_isRoam) {
        _dmapOut[p_channel].map_mode = 1;
    }
    else {
        _dmapOut[p_channel].map_mode = 0;
    }
}

void DMap::setRoamKeyUp(int32_t p_channel, bool p_status)
{
    static uint32_t s_keep[2] = {0, 0};

    if (p_status) {
        _dmapOut[p_channel].upPress = 1;
        s_keep[p_channel] = KEEP_PRAME;
        return;
    }

    if (s_keep[p_channel] > 1) {
        s_keep[p_channel]--;
    }
    else if (s_keep[p_channel] == 1) {
        _dmapOut[p_channel].upPress = 0;
        s_keep[p_channel]--;
    }
}

void DMap::setRoamKeyDown(int32_t p_channel, bool p_status)
{
    static uint32_t s_keep[2] = { 0, 0 };

    if (p_status) {
        _dmapOut[p_channel].downPress = 1;
        s_keep[p_channel] = KEEP_PRAME;
        return;
    }

    if (s_keep[p_channel] > 1) {
        s_keep[p_channel]--;
    }
    else if (s_keep[p_channel] == 1) {
        _dmapOut[p_channel].downPress = 0;
        s_keep[p_channel]--;
    }
}

void DMap::setRoamKeyLeft(int32_t p_channel, bool p_status)
{
    static uint32_t s_keep[2] = { 0, 0 };

    if (p_status) {
        _dmapOut[p_channel].leftPress = 1;
        s_keep[p_channel] = KEEP_PRAME;
        return;
    }

    if (s_keep[p_channel] > 1) {
        s_keep[p_channel]--;
    }
    else if (s_keep[p_channel] == 1) {
        _dmapOut[p_channel].leftPress = 0;
        s_keep[p_channel]--;
    }
}

void DMap::setRoamKeyRight(int32_t p_channel, bool p_status)
{
    static uint32_t s_keep[2] = { 0, 0 };

    if (p_status) {
        _dmapOut[p_channel].rightPress = 1;
        s_keep[p_channel] = KEEP_PRAME;
        return;
    }

    if (s_keep[p_channel] > 1) {
        s_keep[p_channel]--;
    }
    else if (s_keep[p_channel] == 1) {
        _dmapOut[p_channel].rightPress = 0;
        s_keep[p_channel]--;
    }
}

void DMap::setRoamPixelPos(int32_t p_xPos, int32_t p_yPos)
{
    HWND hwnds[2];
    hwnds[0] = FindWindow(NULL, L"First");
    hwnds[1] = FindWindow(NULL, L"Second");
    for (int i = 0; i < 2; i++) {
        if (!hwnds[i]) {
            continue;
        }

        RECT rect;
        GetWindowRect(hwnds[i], &rect);
        if (p_xPos < rect.left ||
            p_xPos > rect.right ||
            p_yPos < rect.top ||
            p_yPos > rect.bottom) {
            continue;
        }

        int32_t xPos = p_xPos - rect.left;
        int32_t yPos = rect.bottom - p_yPos;
        std::thread test(&DMap::setRoamPixelPosThread, this, i, xPos, yPos);
        test.detach();
    }
}

void DMap::setRoamPixelPosThread(int32_t channel, int32_t p_xPos, int32_t p_yPos)
{
    int32_t frameCount = 3;
    while (frameCount--) {
        _dmapOut[channel].mouseClick = 1;
        _dmapOut[channel].xPixel = p_xPos;
        _dmapOut[channel].yPixel = p_yPos;
        Sleep(1);
    }
    _dmapOut[channel].mouseClick = 0;
}

void DMap::getDisAndAngleByGeo(Geo_Wgs84_t* s, Geo_Wgs84_t* e, double* dis, double* alpha)
{
    Vec3d s3d = Geo_Wgs84_To_Ecef(s);
    Vec3d e3d = Geo_Wgs84_To_Ecef(e);
    *dis = sqrt((s3d.x - e3d.x) * (s3d.x - e3d.x) + (s3d.y - e3d.y) * (s3d.y - e3d.y) +
        (s3d.z - e3d.z) * (s3d.z - e3d.z));
    *alpha = Geo_Deg_With_North(s->lon, s->lat, e->lon, e->lat);
}