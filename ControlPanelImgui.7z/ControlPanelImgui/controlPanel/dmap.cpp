#include <stdio.h>
#include "dMap.h"
#include "sharedMem.h"
#include "MAP_Geo.h"

DMap::DMap()
{
	_dmapOut = (DmapOut*)_sharedMem.init();
}

DMap::~DMap()
{
}

void DMap::run(int32_t channel)
{
	//for (int32_t i = 0; i < 2; i++) {
#if 0
		_dmapOut[channel].longitude = 121.793333333948;
		_dmapOut[channel].latitude = 31.1449999998139;
		_dmapOut[channel].altitude = 2000.0;
		_dmapOut[channel].pitch = -90.0;
		_dmapOut[channel].heading = 0.0;
		_dmapOut[channel].roll = 0.0;
		_dmapOut[channel].ring_range = 100.0 * 1000.0;
		_dmapOut[channel].map_mode = 1;
#endif
	//}

    Geo_Wgs84_t    cur_loc = { 0.0 };
    static double angle[2] = { 0.0 };
    int32_t          line_index = 0;
    static uint32_t  framecount[2] = { 0 };
    static int32_t   init_flag = 0;

    static int32_t init[2] = { 0 };
    static int32_t alt = 1000;
    static int32_t alt_dir[2] = { 1 };
    static double     step = 50.0;

    Geo_Wgs84_t  lujiazui = { 121.49971691534425, 31.239658843127756, 3.0 };
    Geo_Wgs84_t  pudong = { 121.793333333948, 31.1449999998139, 3.0 };
    Geo_Wgs84_t  hangzhou = { 120.793333333948, 30.1449999998139, 3.0 };
    Geo_Wgs84_t  jinwan = { 113.39579, 22.01721, 3.0 };
    Geo_Wgs84_t  jiujiang = { 116.1, 29.5, 3.0 };
    Geo_Wgs84_t  temDes = { 113.39579, 42.01721, 3.0 };
    Geo_Wgs84_t  yueyang = { 113.1, 29.5, 3.0 };
    Geo_Wgs84_t  testP = { 112.6, 31.5, 3.0 };

    Geo_Wgs84_t* pDest = &pudong;
    Geo_Wgs84_t* pSrc = &jinwan;
    if (channel == 1) {
        pDest = &pudong;
        pSrc = &jinwan;
    }
    else {
        pDest = &jiujiang;
        pSrc = &hangzhou;
    }
    static double dis[2] = { 0.0 };
    static double heading[2] = { 0.0 };
    if (init[channel] == 0) {
        init[channel] = 1;
        getDisAndAngleByGeo(pSrc, pDest, &dis[channel], &heading[channel]);
    }
    double step_away = step * framecount[channel];
    double ratio = step_away / dis[channel];
    if (step_away > dis[channel])
        framecount[channel] = 0;
    Geo_Wgs84_t pos;
    pos.lon = pSrc->lon + ratio * (pDest->lon - pSrc->lon);
    pos.lat = pSrc->lat + ratio * (pDest->lat - pSrc->lat);
    alt += alt_dir[channel] * 20.0;
    if (alt > 3000) {
        alt_dir[channel] = -1;
    }
    else if (alt < 900) {
        alt_dir[channel] = 1;
    }
    pos.alt = alt;


    framecount[channel]++;

    Geo_Normalize_Lonlat(&pos);

    _dmapOut[channel].longitude = pos.lon;
    _dmapOut[channel].latitude = pos.lat;
    _dmapOut[channel].altitude = pos.alt;
    _dmapOut[channel].heading = heading[channel];
    _dmapOut[channel].ring_range = 100.0 * 1000.0;
    _dmapOut[channel].map_mode = 0;
    printf("%f %f %f %f\n", _dmapOut[0].longitude, _dmapOut[channel].latitude, _dmapOut[channel].altitude, _dmapOut[channel].heading);
}

void DMap::getDisAndAngleByGeo(Geo_Wgs84_t* s, Geo_Wgs84_t* e, double* dis, double* alpha)
{
    Vec3d s3d = Geo_Wgs84_To_Ecef(s);
    Vec3d e3d = Geo_Wgs84_To_Ecef(e);
    *dis = sqrt((s3d.x - e3d.x) * (s3d.x - e3d.x) + (s3d.y - e3d.y) * (s3d.y - e3d.y) +
        (s3d.z - e3d.z) * (s3d.z - e3d.z));
    *alpha = Geo_Deg_With_North(s->lon, s->lat, e->lon, e->lat);
}