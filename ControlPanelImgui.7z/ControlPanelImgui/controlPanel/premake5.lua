project "controlPanel"
    kind "ConsoleApp"
	language "C++"
	cppdialect "C++17"
	staticruntime "off"
	
	debugdir "%{wks.location}/../bin"
	targetdir ("%{wks.location}/../bin/" .. outputdir .. "/%{prj.name}")
	objdir ("%{wks.location}/obj/" .. outputdir .. "/%{prj.name}")
	
	files
	{	
        "premake5.lua",
		"**.cpp",
        "**.c",
		"**.h"
	}

	includedirs
	{
        "%{imguiDir}",
		"%{imguiDir}/backends"
	}

	links
	{
		"imgui",
		"opengl32"
	}

	filter "system:windows"
		systemversion "latest"
		
		defines
		{
			"_CRT_SECURE_NO_WARNINGS",
		}
		
		postbuildcommands
		{
			--("{COPY} %{wks.location}/../3rdParty/OpenGL/bin ../bin/" .. outputdir .. "/%{prj.name}")
		}

	filter "configurations:Debug"
		defines "ENABLE_DEBUG"
		runtime "Debug"
		symbols "on"

	filter "configurations:Release"
		runtime "Release"
		optimize "on"